class Teacher < ApplicationRecord

has_many :subjects
	
end
