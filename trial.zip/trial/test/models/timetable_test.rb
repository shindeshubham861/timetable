require 'test_helper'

class TimetableTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
